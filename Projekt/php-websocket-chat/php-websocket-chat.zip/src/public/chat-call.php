<?php

header("Location: ./chat.php?username=" . $_POST['username']);
