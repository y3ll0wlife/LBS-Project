import React, { Component } from "react";

export default class _404 extends Component {
	render() {
		return (
			<>
				<br />
				<div className="text-center" style={{ color: "white" }}>
					<h1>
						<strong>404</strong>
					</h1>

					<br />
				</div>
			</>
		);
	}
}
