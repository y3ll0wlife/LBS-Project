Installation guide for this project

First install required node modules
$ npm install
or 
$ yarn install

Then we can run the project with the following command, this will start a dev server on port 3000
$ npm run start
or
$ yarn start

If you want to build the project
$ npm run build
or 
$ yarn build